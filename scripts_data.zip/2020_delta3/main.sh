
avapsgetstormspeed.sh /home/pi/Desktop/STORM_REPORTS/REPORT_20_DELTA.txt 2020 10 07 21 00

#Storm speed (vx, vy): -7.201639 3.086417 
avapslonlatStorm.sh -7.2 3.1 75.6

avaps3dvarONR_withoutRADAR.sh 2020 10 07 mask -94.5 0.25 46 20 0.25 32 0 0.2 81 -7.2 3.1 75.6 18 24 1

cat merge.cdf | uniput -r ../2020_delta3.nc
