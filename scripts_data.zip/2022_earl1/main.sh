avapsgetstormspeed.sh /home/pi/Desktop/STORM_REPORTS/REPORT_22_EARL.txt 2022 08 28 22 30
#Storm speed (vx, vy): -4.286690 1.886144  

avapslonlatStorm.sh 0.0 0.0 81.0


avaps3dvarONR_withoutRADAR.sh 2022 08 31 mask -51 0.25 40 11.5 0.25 28 0 0.2 81 0.0 0.0 81.0 16 22 1

cat merge.cdf | uniput -r ../2022_earl1.nc


