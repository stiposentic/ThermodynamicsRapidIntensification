

avapsgetstormspeed.sh /home/pi/Desktop/STORM_REPORTS/REPORT_10_KARL.txt 2010 09 12 13 30
#Storm speed (vx, vy): -6.8 0.0 at 13:30utc
#Taken from Saska's work: as the BT data does not have this time

avapslonlatStorm.sh -6.8 0.0 48.6

avaps3dvarONR_withoutRADAR.sh 2010 09 12 mask -72.5 0.25 32 12.5 0.25 28 0 0.2 81 -6.8 0.0 48.6 4 14 2
# use NaN cloud top temp as we do not have GOES16 cloud top temp for then  


cat merge.cdf | uniput ../2010_karl4.nc
