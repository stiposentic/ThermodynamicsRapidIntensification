avapsgetstormspeed.sh /home/pi/Desktop/STORM_REPORTS/REPORT_20_DELTA.txt 2020 10 07 11 00
#Storm speed (vx, vy): -8.001821 5.258340 
avapslonlatStorm.sh -8.0 5.3 39.6

avaps3dvarONR_withoutRADAR.sh 2020 10 07 mask -91 0.25 32 17.5 0.25 38 0 0.2 81 -8.0 5.3 39.6 6 13 0

cat merge.cdf | uniput -r ../2020_delta2.nc
