

avapsgetstormspeed.sh /home/pi/Desktop/STORM_REPORTS/REPORT_23_IDALIA.txt 2023 08 28 22 15
#Storm speed (vx, vy): 0.514403 3.086417 
avapslonlatStorm.sh 0.5 3.1 80.1


# using storm speed from radar data
avaps3dvarONR_withoutRADAR.sh 2023 08 28 mask -87.5 0.25 20 18.5 0.25 32 0 0.2 81 0.5 3.1 80.1 18 24 0


cat merge.cdf | uniput ../2023_idalia3.nc
