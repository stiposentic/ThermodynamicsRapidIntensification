avapsgetstormspeed.sh /home/pi/Desktop/STORM_REPORTS/REPORT_20_LAURA.txt 2020 08 25 09 00 
#Storm speed (vx, vy): -7.458840 2.829215 

avapslonlatStorm.sh -7.5 2.8 32.4

avaps3dvarONR_withoutRADAR.sh 2020 08 25 mask -90.5 0.25 32 20 0.25 40 0 0.2 81 -7.5 2.8 32.4 6 12 0


cat merge.cdf | uniput -r ../2020_laura5.nc


