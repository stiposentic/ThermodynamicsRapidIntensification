

#avapsgetstormspeed.sh /home/pi/Desktop/STORM_REPORTS/REPORT_10_NICOLE.txt 2010 08 17 12 00
#Storm speed (vx, vy): -8.0 0.0 at 12 utc (from Saska) 

avapslonlatStorm.sh -8.0 0.0 43.2

avaps3dvarONR_withoutRADAR.sh 2010 08 17 mask -72.5 0.25 32 12.5 0.25 22 0 0.2 81 -8.0 0.0 43.2 4 14 2
# use NaN cloud top temp as we do not have GOES16 cloud top temp for then  


cat merge.cdf | uniput ../2010_PGI027-1.nc
