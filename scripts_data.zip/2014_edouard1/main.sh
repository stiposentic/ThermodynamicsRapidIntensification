

avapsgetstormspeed.sh /home/pi/Desktop/STORM_REPORTS/REPORT_14_EDOUARD.txt 2014 09 12 09 00
# edouard 1 speed:
# Storm speed (vx, vy): -7.973243 2.829215

avapslonlatStorm.sh -8.0 2.8 32.4

# using storm speed from radar data
avaps3dvarONR_withoutRADAR.sh 2014 09 12 mask -45.5 0.25 28 13.5 0.25 36 0 0.2 81 -8.0 2.8 32.4 4 14 2
# use NaN cloud top temp as we do not have GOES16 cloud top temp for then  


cat merge.cdf | uniput ../2014_edouard1.nc
