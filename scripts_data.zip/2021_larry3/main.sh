
avapsgetstormspeed.sh /home/pi/Desktop/STORM_REPORTS/REPORT_21_LARRY.txt 2021 09 07 18 00
#Storm speed (vx, vy): -3.086417 3.600819 

avapslonlatStorm.sh -3.1 3.6 64.8

avaps3dvarONR_withoutRADAR.sh 2021 09 07 mask -60 0.25 28 22 0.25 28 0 0.2 81 -3.1 3.6 64.8 16 20 1

cat merge.cdf | uniput -r ../2021_larry3.nc
