

avapsgetstormspeed.sh /home/pi/Desktop/STORM_REPORTS/REPORT_10_KARL.txt 2010 09 10 19 00
#Storm speed (vx, vy): -2.0 0.9 at 19utc
#Taken from Saska's work: as the BT data does not have this time

avapslonlatStorm.sh -2.0 0.9 68.4

avaps3dvarONR_withoutRADAR.sh 2010 09 10 mask -64.5 0.25 30 11 0.25 20 0 0.2 81 -2.0 0.9 68.4 4 14 2
# use NaN cloud top temp as we do not have GOES16 cloud top temp for then  


cat merge.cdf | uniput ../2010_karl2.nc
