

avapsgetstormspeed.sh /home/pi/Desktop/STORM_REPORTS/REPORT_10_GASTON.txt 2010 09 03 17 00
#Storm speed (vx, vy): -3.600819 2.486280 

avapslonlatStorm.sh -3.6 2.5 61.2

avaps3dvarONR_withoutRADAR.sh 2010 09 03 mask -47 0.25 38 12 0.25 22 0 0.2 81 -3.6 2.5 62.2 4 14 2
# use NaN cloud top temp as we do not have GOES16 cloud top temp for then  


cat merge.cdf | uniput ../2010_gaston2.nc
