avapsgetstormspeed.sh /home/pi/Desktop/STORM_REPORTS/REPORT_21_HENRI.txt 2021 08 19 22 30
#Storm speed (vx, vy): -5.144028 0.514403 

avapslonlatStorm.sh -5.1 0.5 81.0


avaps3dvarONR_withoutRADAR.sh 2021 08 19 mask -76 0.25 44 26 0.25 38 0 0.2 81 -5.1 0.5 81.0 19 26 0

cat merge.cdf | uniput -r ../2021_henri1.nc




