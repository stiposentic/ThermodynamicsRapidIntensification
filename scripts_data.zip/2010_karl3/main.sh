

avapsgetstormspeed.sh /home/pi/Desktop/STORM_REPORTS/REPORT_10_KARL.txt 2010 09 11 18 00
#Storm speed (vx, vy): -6.0 0.0 at 17:45utc
#Taken from Saska's work: as the BT data does not have this time

avapslonlatStorm.sh -6.0 0.0 64.8

avaps3dvarONR_withoutRADAR.sh 2010 09 10 mask -69 0.25 38 12.5 0.25 20 0 0.2 81 -6.0 0.0 64.8 4 14 2
# use NaN cloud top temp as we do not have GOES16 cloud top temp for then  


cat merge.cdf | uniput ../2010_karl3.nc
