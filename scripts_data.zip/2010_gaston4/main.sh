

avapsgetstormspeed.sh /home/pi/Desktop/STORM_REPORTS/REPORT_10_GASTON.txt 2010 09 06 14 15
#Storm speed (vx, vy): -8.101844 0.514403 

avapslonlatStorm.sh -8.1 0.5 51.3

avaps3dvarONR_withoutRADAR.sh 2010 09 06 mask -60 0.25 34 13.5 0.25 28 0 0.2 81 -8.1 0.5 51.3 4 14 2
# use NaN cloud top temp as we do not have GOES16 cloud top temp for then  


cat merge.cdf | uniput ../2010_gaston4.nc
