

avapsgetstormspeed.sh /home/pi/Desktop/STORM_REPORTS/REPORT_10_MATTHEW.txt 2010 09 20 15 30
#Storm speed (vx, vy): -5.1 -1.5 at 15utc
# Values take nfrom Saskas work as we do not have BT data forthis time

avapslonlatStorm.sh -5.1 -1.5 55.8

avaps3dvarONR_withoutRADAR.sh 2010 09 20 mask -59 0.25 28 9.5 0.25 22 0 0.2 81 -5.1 -1.5 53.8 4 14 2
# use NaN cloud top temp as we do not have GOES16 cloud top temp for then  


cat merge.cdf | uniput ../2010_matthew1.nc
