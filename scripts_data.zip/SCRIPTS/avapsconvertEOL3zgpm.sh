#!/bin/bash
#####################################################
#####################################################
## Takes dropsonde files from the OTREC project    ##
## and convertes them to candis formatting         ##
## without any calculations.                       ##
## All output files will have the following naming ##
## convention: YYYYMMDD_HHMMSS_raw.cdf             ##
## Script written by Charles Jensen and modified   ##
## by Dave Raymond                                 ##
#####################################################
#####################################################

if test $# != 3
then
	echo "Usage: $0 eol_dropsonde_file sondeNumber multiplier"
else
	# Input file
	infile=$1
	NNN=$2
        multiplier=$3

	#Header length
	header=15

	# Stuff to collect information from the name of the file
	year=`echo $infile | cut -c 2-5`
	mon=`echo $infile | cut -c 6-7`
	day=`echo $infile | cut -c 8-9`
	hour=`echo $infile | cut -c 11-12`
	min=`echo $infile | cut -c 13-14`
	sec=`echo $infile | cut -c 15-16`

	# Produce the name of the output file
	outfile=Z${year}${mon}${day}_${hour}${min}${sec}.cdf

        # remove any lines with bad data
       	octave ~/bin/eolRemoveBadLines.m $infile


	# create the output file -- convert z to km
	#tail -n +$header < $infile | \
	#	sed -e "s/-999.000/1e30/g" | \
        #        sed -e "s/-999.000000/1e30/g" | \
        #        sed -e "s/-999.00/1e30/g" | \
        #        sed -e "s/999.00/1e30/g" | \
        #        sed -e "s/-999.0/1e30/g" | \
        #        sed -e "s/999.0/1e30/g" | \
        #        sed -e "s/-999/1e30/g" |\
        #        #sed 'n;d' |\
	cat $infile.nobad |\
		cdftable time hh mm ss pres temp dewpt rh \
		u_wind v_wind wspd dir dz zgeopot lon lat z | \
		cdfmath 'z 1000 / z =' | \
		cdfcat index 0 5000 5001  | \
		cdffill index | \
		cdfinvindex index z |\
		cdfwindow z 16 0 | \
		cdfinterp z 16 -0.02 801 | \
		cdfmean z .m lon lat | \
		cdfmath "$year year =" | \
		cdfmath "$mon mon =" | \
		cdfmath "$day day =" | \
		cdfentropy -d pres temp temp satent satmr |\
                cdfmath "satmr rh 100 / * mr =" |\
                cdfextr -p z0 dz | \
                cdfmath "$NNN NNN =" |\
		cdfjday year mon day jday $year 1 0 | \
		cdfmath "$hour 3600 * $min 60 * + $sec + ztime =" | \
		cdfmath "ztime 86400 $multiplier * + ztime =" | \
		cdfmath "jday ztime 86400 / + jday =" | \
		cdfextr -p z0 dz | \
		cdfextr ztime jday lon lat lon.m lat.m pres temp mr dewpt \
			u_wind v_wind NNN rh |\
	        gosndextrap > $outfile
fi
