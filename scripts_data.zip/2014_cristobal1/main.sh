

avapsgetstormspeed.sh /home/pi/Desktop/STORM_REPORTS/REPORT_14_CRISTOBAL.txt 2014 08 27 04 30
#Storm speed (vx, vy): -1.714676 6.301434 3:30am
#Storm speed (vx, vy): -2.057611 6.044233 4:30am

avapslonlatStorm.sh -2.1 6.0 16.2

avaps3dvarONR_withoutRADAR.sh 2014 08 27 mask -77 0.25 60 25 0.25 46 0 0.2 81 -2.1 6.0 12.6 4 14 2
# use NaN cloud top temp as we do not have GOES16 cloud top temp for then  


cat merge.cdf | uniput ../2014_cristobal1.nc
