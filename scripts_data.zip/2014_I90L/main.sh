

#avapsgetstormspeed.sh /home/pi/Desktop/STORM_REPORTS/REPORT_13_HUMBERTO.txt 2014 09 05 23 00
# gabrielle 1 speed: 0 0
# as it was a depression and not noted in the NHC reports
#Storm speed (vx, vy): 0.507258 0.514403 


# ana's speed: -7.5 2.6
# 23 h

avapslonlatStorm.sh -7.5 2.6 82.8


avaps3dvarONR_withoutRADAR.sh 2014 09 05 mask -34.25 0.25 42 7.5 0.25 42 0 0.2 81 -7.5 2.6 82.8 18 29 2
# use NaN cloud top temp as we do not have GOES16 cloud top temp for then  


cat merge.cdf | uniput ../2014_I90L.nc
