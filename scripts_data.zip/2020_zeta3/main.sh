avapsgetstormspeed.sh /home/pi/Desktop/STORM_REPORTS/REPORT_20_ZETA.txt 2020 10 26 22 00 
#Storm speed (vx, vy): -4.629625 2.572014 

avapslonlatStorm.sh -4.6 2.6 79.2

avaps3dvarONR_withoutRADAR.sh 2020 10 26 mask -89 0.25 24 17 0.25 48 0 0.2 81 -4.6 2.6 79.2 18 24 0


cat merge.cdf | uniput -r ../2020_zeta3.nc


