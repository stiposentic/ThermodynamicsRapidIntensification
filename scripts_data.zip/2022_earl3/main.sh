avapsgetstormspeed.sh /home/pi/Desktop/STORM_REPORTS/REPORT_22_EARL.txt 2022 09 01 20 30
#Storm speed (vx, vy):-5.958499 2.057611 
avapslonlatStorm.sh -6.0 2.1 73.8


avaps3dvarONR_withoutRADAR.sh 2022 09 01 mask -61.5 0.25 30 15 0.25 28 0 0.2 81 -6.0 2.1 73.8 19 22 1

cat merge.cdf | uniput -r ../2022_earl3.nc


