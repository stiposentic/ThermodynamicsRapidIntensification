

avapsgetstormspeed.sh /home/pi/Desktop/STORM_REPORTS/REPORT_10_MATTHEW.txt 2010 09 22 19 15
#Storm speed (vx, vy): NaN NaN

# taken from Saskas work
avapslonlatStorm.sh -6.0 0.0 69.3

avaps3dvarONR_withoutRADAR.sh 2010 09 22 mask -74.5 0.25 28 12 0.25 16 0 0.2 81 -6.0 0.0 69.3 4 14 2
# use NaN cloud top temp as we do not have GOES16 cloud top temp for then  


cat merge.cdf | uniput ../2010_matthew3a.nc
