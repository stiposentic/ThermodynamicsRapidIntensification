

avapsgetstormspeed.sh /home/pi/Desktop/STORM_REPORTS/REPORT_10_MATTHEW.txt 2010 09 23 21 00
#Storm speed (vx, vy): -7.458840 0.771604

avapslonlatStorm.sh -7.5 0.8 75.6


avaps3dvarONR_withoutRADAR.sh 2010 09 23 mask -79.5 0.25 26 11 0.25 22 0 0.2 81 -7.5 0.8 75.6 4 14 2
# use NaN cloud top temp as we do not have GOES16 cloud top temp for then  


cat merge.cdf | uniput ../2010_matthew4a.nc
