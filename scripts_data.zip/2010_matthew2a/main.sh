

avapsgetstormspeed.sh /home/pi/Desktop/STORM_REPORTS/REPORT_10_MATTHEW.txt 2010 09 21 20 00
#Storm speed (vx, vy): NaN NaN

# taken from Saskas work
avapslonlatStorm.sh -6.0 0.0 72.0

avaps3dvarONR_withoutRADAR.sh 2010 09 21 mask -67.5 0.25 24 11.5 0.25 20 0 0.2 81 -6.0 0.0 72.0 4 14 2
# use NaN cloud top temp as we do not have GOES16 cloud top temp for then  


cat merge.cdf | uniput ../2010_matthew2a.nc
