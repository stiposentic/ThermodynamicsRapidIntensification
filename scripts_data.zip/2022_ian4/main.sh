

avapsgetstormspeed.sh /home/pi/Desktop/STORM_REPORTS/REPORT_22_IAN.txt 2022 09 26 08 30
#Storm speed (vx, vy): -3.900888 4.843959 

avapslonlatStorm.sh -3.9 4.8 30.6

avaps3dvarONR_withoutRADAR.sh 2022 09 26 mask -86.5 0.25 32 14.5 0.25 28 0 0.2 81 -3.9 4.8 30.6 6 10 1

cat merge.cdf |  uniput  ../2022_ian4.nc


