

avapsgetstormspeed.sh /home/pi/Desktop/STORM_REPORTS/REPORT_10_KARL.txt 2010 09 13 13 00
#Storm speed (vx, vy): -6.1 2.8 at 13:45utc
#Taken from Saska's work: as the BT data does not have this time

avapslonlatStorm.sh -6.1 2.8 46.8

avaps3dvarONR_withoutRADAR.sh 2010 09 13 mask -80.5 0.25 32 14.5 0.25 20 0 0.2 81 -6.1 2.8 46.8 4 14 2
# use NaN cloud top temp as we do not have GOES16 cloud top temp for then  


cat merge.cdf | uniput ../2010_karl5.nc
