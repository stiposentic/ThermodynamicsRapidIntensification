

avapsgetstormspeed.sh /home/pi/Desktop/STORM_REPORTS/REPORT_23_FRANKLIN.txt 2023 08 22 6 15
#Storm speed (vx, vy): -0.514403 1.307440 
avapslonlatStorm.sh -0.5 1.3 22.5

# using storm speed from radar data
avaps3dvarONR_withoutRADAR.sh 2023 08 22 mask -73.5 0.25 20 13 0.25 20 0 0.2 81 -0.5 1.3 22.5 5 8 1


cat merge.cdf | uniput ../2023_franklin0.nc
