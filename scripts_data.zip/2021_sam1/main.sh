avapsgetstormspeed.sh /home/pi/Desktop/STORM_REPORTS/REPORT_21_SAM.txt 2021 09 25 22 00
#Storm speed (vx, vy): -3.943755 1.543208 

avapslonlatStorm.sh -3.9 1.5 79.2


avaps3dvarONR_withoutRADAR.sh 2021 09 25 mask -51.5 0.25 24 10.5 0.25 20 0 0.2 81 -3.9 1.5 79.2 20 24 0

cat merge.cdf | uniput -r ../2021_sam1.nc




