# grid 0.25
# using storm speed from radar data

avapsgetstormspeed.sh ~/Desktop/STORM_REPORTS/REPORT_22_IAN.txt 2022 09 27 8 15
#Storm speed (vx, vy): -1.265431 4.958843 
avapslonlatStorm.sh -1.3 5.0 29.70

avaps3dvarONR_withoutRADAR.sh 2022 09 27 mask -87.5 0.25 28 18.5 0.25 24 0 0.2 81 -1.3 5.0 29.70 6 10 0

cat merge.cdf | uniput ../2022_ian6.nc
