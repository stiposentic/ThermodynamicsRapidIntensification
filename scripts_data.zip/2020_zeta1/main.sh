avapsgetstormspeed.sh /home/pi/Desktop/STORM_REPORTS/REPORT_20_ZETA.txt 2020 10 25 21 00 
#Storm speed (vx, vy): -0.514403 1.028806 

avapslonlatStorm.sh -0.5 1.0 75.6

avaps3dvarONR_withoutRADAR.sh 2020 10 25 mask -87.5 0.25 58 14 0.25 48 0 0.2 81 -0.5 1.0 75.6 18 24 0


cat merge.cdf | uniput -r ../2020_zeta1.nc

