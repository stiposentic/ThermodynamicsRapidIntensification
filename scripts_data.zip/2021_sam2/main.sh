avapsgetstormspeed.sh /home/pi/Desktop/STORM_REPORTS/REPORT_21_SAM.txt 2021 09 26 21 45
#Storm speed (vx, vy): -1.543208 1.864710 

avapslonlatStorm.sh -1.5 1.9 78.3


avaps3dvarONR_withoutRADAR.sh 2021 09 26 mask -54.5 0.25 28 8.5 0.25 36 0 0.2 81 -1.5 1.9 78.3 19 24 0

cat merge.cdf | uniput -r ../2021_sam2.nc




