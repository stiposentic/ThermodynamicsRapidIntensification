# grid 0.25
# using storm speed from radar data

avapsgetstormspeed.sh /home/pi/Desktop/STORM_REPORTS/REPORT_22_IAN.txt 2022 09 26 20 00
#Storm speed (vx, vy): -2.572014 5.315495 

avapslonlatStorm.sh -2.6 5.3 72.00

avaps3dvarONR_withoutRADAR.sh 2022 09 26 mask -86.5 0.25 26 16.5 0.25 30 0 0.2 81 -2.6 5.3 72.0 18 22 0

cat merge.cdf | uniput ../2022_ian5.nc
