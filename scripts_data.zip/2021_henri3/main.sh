avapsgetstormspeed.sh /home/pi/Desktop/STORM_REPORTS/REPORT_21_HENRI.txt 2021 08 20 22 00
#Storm speed (vx, vy): -0.000000 3.943755 

avapslonlatStorm.sh 0.0 3.9 79.2


avaps3dvarONR_withoutRADAR.sh 2021 08 20 mask -78 0.25 48 26 0.25 40 0 0.2 81 0.0 3.9 79.2 18 25 0

cat merge.cdf | uniput -r ../2021_henri3.nc




