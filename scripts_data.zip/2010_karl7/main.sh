

avapsgetstormspeed.sh /home/pi/Desktop/STORM_REPORTS/REPORT_10_KARL.txt 2010 09 16 20 30
#Storm speed (vx, vy): -5.015427 0.214334 

avapslonlatStorm.sh -5.0 0.2 73.8

avaps3dvarONR_withoutRADAR.sh 2010 09 16 mask -97.5 0.25 31 18 0.25 30 0 0.2 81 -5.0 0.2 73.8 4 14 2
# use NaN cloud top temp as we do not have GOES16 cloud top temp for then  


cat merge.cdf | uniput ../2010_karl7.nc
