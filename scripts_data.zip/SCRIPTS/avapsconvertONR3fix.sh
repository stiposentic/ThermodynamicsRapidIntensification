#!/bin/bash
#####################################################
#####################################################
## Takes dropsonde files from the OTREC project    ##
## and convertes them to candis formatting         ##
## without any calculations.                       ##
## All output files will have the following naming ##
## convention: YYYYMMDD_HHMMSS_raw.cdf             ##
## Script written by Charles Jensen and modified   ##
## by Dave Raymond and Stipo Sentic                ##
#####################################################
#####################################################

# stipo addition: this modified version corrects 
# files which are mising z height data

if test $# != 3
then
	echo "Usage: $0 eol_dropsonde_file number_of_sonde"
else
	# Input file
	infile=$1
	NNN=$2
	multiplier=$3

	#Header length
	header=70
	header=22
	#$dir/*.frd


	# Stuff to collect information from the name of the file
	year=`echo $infile | cut -c 2-5`
	mon=`echo $infile | cut -c 6-7`
	day=`echo $infile | cut -c 8-9`
	hour=`echo $infile | cut -c 11-12`
	min=`echo $infile | cut -c 13-14`
	sec=`echo $infile | cut -c 15-16`
	
	#year=`echo $infile | cut -c 22-25`
	#mon=`echo $infile | cut -c 26-27`
	#day=`echo $infile | cut -c 28-29`
	#hour=`echo $infile | cut -c 31-32`
	#min=`echo $infile | cut -c 33-34`
	#sec=`echo $infile | cut -c 35-36`


	# Produce the name of the output file
	outfile=Z${year}${mon}${day}_${hour}${min}${sec}.cdf

	#lonR=`cat $infile | cdfextr reference_lat reference_lon | cdfrdim obs 0 | cdflook | egrep "reference_lon"`
	#latR=`cat $infile | cdfextr reference_lat reference_lon | cdfrdim obs 0 | cdflook | egrep "reference_lat"`
        #lonR=`echo $lonR | cut -c 39-48`
	#latR=`echo $latR | cut -c 39-48`

#echo here	
	# create the output file -- convert z to km
	tail -n +$header < $infile | \
		sed -e "s/-999.000/1e30/g" | \
                sed -e "s/-999.00/1e30/g" | \
                sed -e "s/-999.0/1e30/g" | \
		sed -e "s/-999/1e30/g" | \
		sed 'n;d' > temp.asc

	# input file temp.asc, output tmp.txt
	octave ~/bin/avapsfixZ.m


	cat tmp.txt |\
	        cdftable ix time pres temp rh alt wd ws \
		u_wind v_wind ns wz  zw fp ft fh fw lat lon | \
		cdfparams bad 9.99999e+29 badlim 9.99e+29 |\
		cdfcat index 0 20000 99999 |\
		cdffill index |\
		cdfmath "alt 1000 / z =" |\
		cdfinvindex index z |\
		#cdfwindow z 16 0 > tmp
		cdfinterp z 16 -0.02 801 |\
		cdfmean z .m lon lat | \
		cdfmath "$year year =" | \
		cdfmath "$mon mon =" | \
		cdfmath "$day day =" | \
		cdfjday year mon day jday $year 1 0 | \
		cdfmath "$hour 3600 * $min 60 * + $sec + ztime =" | \
		cdfmath "jday ztime 86400 / + jday =" | \
		cdfmath "ztime 86400 $multiplier * + ztime =" | \
		cdfentropy -d pres temp temp satent satmr |\
		cdfmath "satmr rh 100 / * mr =" |\
		cdfextr -p z0 dz | \
		cdfmath "$NNN NNN =" |\
		cdfextr ztime jday lon lat lon.m lat.m pres temp mr \
			u_wind v_wind NNN |
		       gosndextrap |\
		cdfentropy -d pres temp temp satent satmr |\
		 cdfmath "mr satmr / 100 *  rh =" |\
		 cdfextr ztime jday lon lat lon.m lat.m pres temp mr \
                        u_wind v_wind NNN rh > $outfile
	#echo here end
	rm temp.asc tmp.txt
		#exit
fi

