

avapsgetstormspeed.sh /home/pi/Desktop/STORM_REPORTS/REPORT_10_GASTON.txt 2010 09 07 14 30
#Storm speed (vx, vy): -9.773653 -0.900205 

avapslonlatStorm.sh -9.8 -0.9 52.2

avaps3dvarONR_withoutRADAR.sh 2010 09 07 mask -67.5 0.25 32 14 0.25 28 0 0.2 81 -9.8 -0.9 52.2 4 14 2
# use NaN cloud top temp as we do not have GOES16 cloud top temp for then  


cat merge.cdf | uniput ../2010_gaston5.nc
