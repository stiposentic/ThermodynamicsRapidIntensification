avapsgetstormspeed.sh /home/pi/Desktop/STORM_REPORTS/REPORT_21_SAM.txt 2021 09 27 20 30
#Storm speed (vx, vy): -3.086417 2.786348 

avapslonlatStorm.sh -3.1 2.8 73.8

avaps3dvarONR_withoutRADAR.sh 2021 09 27 mask -56.5 0.25 28 13 0.25 46 0 0.2 81 -3.1 2.8 73.8 19 25 0

cat merge.cdf | uniput -r ../2021_sam3.nc




