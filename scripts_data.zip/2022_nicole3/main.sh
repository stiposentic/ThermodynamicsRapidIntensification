avapsgetstormspeed.sh /home/pi/Desktop/STORM_REPORTS/REPORT_22_NICOLE.txt 2022 11 09 10 30
#Storm speed (vx, vy): -4.758226 -1.671809

avapslonlatStorm.sh -4.8 -1.7 37.8

avaps3dvarONR_withoutRADAR.sh 2022 11 09 mask -80 0.25 36 21.5 0.25 44 0 0.2 81 -4.8 -1.7 37.8 8 13 1

cat merge.cdf | uniput -r ../2022_nicole3.nc


