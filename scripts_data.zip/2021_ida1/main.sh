avapsgetstormspeed.sh /home/pi/Desktop/STORM_REPORTS/REPORT_21_IDA.txt 2021 08 27 09 00
#Storm speed (vx, vy): -3.858021 5.401229 

avapslonlatStorm.sh -3.9 5.4 32.4


avaps3dvarONR_withoutRADAR.sh 2021 08 27 mask -86 0.25 52 17 0.25 40 0 0.2 81 -3.9 5.4 32.4 6 12 0

cat merge.cdf | uniput -r ../2021_ida1.nc




