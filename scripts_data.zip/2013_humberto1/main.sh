

avapsgetstormspeed.sh /home/pi/Desktop/STORM_REPORTS/REPORT_13_HUMBERTO.txt 2013 09 16 23 59
# gabrielle 1 speed: 0 0
# as it was a depression and not noted in the NHC reports
#Storm speed (vx, vy): 0.507258 0.514403 

avapslonlatStorm.sh 0.5 0.5 86.4


avaps3dvarONR_withoutRADAR.sh 2013 09 16 mask -50 0.25 48 25.5 0.25 34 0 0.2 81 0.5 0.5 86.4 18 29 2
# use NaN cloud top temp as we do not have GOES16 cloud top temp for then  


cat merge.cdf | uniput ../2013_humberto1.nc
