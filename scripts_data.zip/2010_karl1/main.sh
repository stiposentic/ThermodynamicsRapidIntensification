

avapsgetstormspeed.sh /home/pi/Desktop/STORM_REPORTS/REPORT_10_KARL.txt 2010 09 10 11 30
#Storm speed (vx, vy): -5.1 0 at 11:15
#Taken from Saska's work: as the BT data does not have this time

avapslonlatStorm.sh -5.1 0.0 40.5

avaps3dvarONR_withoutRADAR.sh 2010 09 10 mask -64.5 0.25 36 10 0.25 22 0 0.2 81 -5.1 0.0 40.5 4 14 2
# use NaN cloud top temp as we do not have GOES16 cloud top temp for then  


cat merge.cdf | uniput ../2010_karl1.nc
