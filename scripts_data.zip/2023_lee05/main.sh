

avapsgetstormspeed.sh /home/pi/Desktop/STORM_REPORTS/REPORT_23_LEE.txt 2023 09 12 21 07
# Storm speed (vx, vy): -2.552009 2.077616 
avapslonlatStorm.sh -2.6 2.1 76.05

# using storm speed from NHC reports: 
avaps3dvarONR_withoutRADAR.sh 2023 09 12 mask -70 0.25 36 19.5 0.25 36 0 0.2 81 -2.6 2.1 76.05 19 23 0


cat merge.cdf | uniput ../2023_lee05.nc
