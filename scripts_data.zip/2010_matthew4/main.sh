

avapsgetstormspeed.sh /home/pi/Desktop/STORM_REPORTS/REPORT_10_MATTHEW.txt 2010 09 24 16 00
#Storm speed (vx, vy): -8.9 0.0 at 16utc (from Saska's work)
# Values take from BT because we have them there, compared to Saska's above
# we see that they are close
#Storm speed (vx, vy): -9.602185 1.714676 

avapslonlatStorm.sh -9.6 1.7 57.6

avaps3dvarONR_withoutRADAR.sh 2010 09 24 mask -83.5 0.25 24 11 0.25 28 0 0.2 81 -9.6 1.7 57.6 4 14 2
# use NaN cloud top temp as we do not have GOES16 cloud top temp for then  


cat merge.cdf | uniput ../2010_matthew4.nc
