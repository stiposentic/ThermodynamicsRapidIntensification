

avapsgetstormspeed.sh /home/pi/Desktop/STORM_REPORTS/REPORT_10_KARL.txt 2010 09 12 22 00
#Storm speed (vx, vy): NaN NaN

# taken from ana's paper
avapslonlatStorm.sh -6.4 1.5 79.2

avaps3dvarONR_withoutRADAR.sh 2010 09 12 mask -74.5 0.25 28 12.5 0.25 22 0 0.2 81 -6.4 1.5 79.2 4 14 2
# use NaN cloud top temp as we do not have GOES16 cloud top temp for then  


cat merge.cdf | uniput ../2010_karl4a.nc
