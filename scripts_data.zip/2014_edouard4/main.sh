

avapsgetstormspeed.sh /home/pi/Desktop/STORM_REPORTS/REPORT_14_EDOUARD.txt 2014 09 18 22 00
#Storm speed (vx, vy): 10.288056 0.000000 

avapslonlatStorm.sh 10.3 0.0 79.2


avaps3dvarONR_withoutRADAR.sh 2014 09 18 mask -46.5 0.25 52 33.5 0.25 50 0 0.2 81 10.3 0.0 80.1 4 14 2
# use NaN cloud top temp as we do not have GOES16 cloud top temp for then  


cat merge.cdf | uniput ../2014_edouard4.nc
