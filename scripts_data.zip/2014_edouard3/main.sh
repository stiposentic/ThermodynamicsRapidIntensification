

avapsgetstormspeed.sh /home/pi/Desktop/STORM_REPORTS/REPORT_14_EDOUARD.txt 2014 09 16 23 45
#Storm speed (vx, vy): 3.472219 6.151400 

avapslonlatStorm.sh 3.5 6.2 85.5

avaps3dvarONR_withoutRADAR.sh 2014 09 16 mask -63.5 0.25 50 27 0.25 40 0 0.2 81 3.5  6.2 85.5 4 14 2
# use NaN cloud top temp as we do not have GOES16 cloud top temp for then  


cat merge.cdf | uniput ../2014_edouard3.nc
