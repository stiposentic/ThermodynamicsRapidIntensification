

#avapsgetstormspeed.sh /home/pi/Desktop/STORM_REPORTS/REPORT_10_NICOLE.txt 2010 08 17 12 00
#Storm speed (vx, vy): -7.0 2.5 at 12:00 utc (from Saska) 

avapslonlatStorm.sh -6.2 2.3 54.9

avaps3dvarONR_withoutRADAR.sh 2010 09 30 mask -59 0.25 30 9 0.25 32 0 0.2 81 -6.2 2.3 54.9 4 14 2
# use NaN cloud top temp as we do not have GOES16 cloud top temp for then  


cat merge.cdf | uniput ../2010_PGI048-050.nc
