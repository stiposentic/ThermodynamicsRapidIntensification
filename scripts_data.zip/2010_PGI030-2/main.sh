

#avapsgetstormspeed.sh /home/pi/Desktop/STORM_REPORTS/REPORT_10_NICOLE.txt 2010 08 17 12 00
#Storm speed (vx, vy): -7.0 2.5 at 12:00 utc (from Saska) 

avapslonlatStorm.sh -7.0 2.5 43.2

avaps3dvarONR_withoutRADAR.sh 2010 08 23 mask -67 0.25 20 19 0.25 16 0 0.2 81 -7.0 2.5 43.2 4 14 2
# use NaN cloud top temp as we do not have GOES16 cloud top temp for then  


cat merge.cdf | uniput ../2010_PGI030-2.nc
