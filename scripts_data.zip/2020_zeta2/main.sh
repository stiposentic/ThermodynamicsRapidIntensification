avapsgetstormspeed.sh /home/pi/Desktop/STORM_REPORTS/REPORT_20_ZETA.txt 2020 10 26 11 30 
#Storm speed (vx, vy): -3.429352 2.014744 

avapslonlatStorm.sh -3.4 2.0 41.4

avaps3dvarONR_withoutRADAR.sh 2020 10 26 mask -88 0.25 34 14 0.25 32 0 0.2 81 -3.4 2.0 41.4 6 13 0


cat merge.cdf | uniput -r ../2020_zeta2.nc


