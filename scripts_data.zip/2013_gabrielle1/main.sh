

avapsgetstormspeed.sh /home/pi/Desktop/STORM_REPORTS/REPORT_13_GABRIELLE.txt 2013 08 29 23 30
# gabrielle 1 speed: 0 0
# as it was a depression and not noted in the NHC reports

avapslonlatStorm.sh 0 0 84.6


avaps3dvarONR_withoutRADAR.sh 2013 08 29 mask -50.5 0.25 44 11 0.25 26 0 0.2 81 0.0 0.0 84.6 4 14 2
# use NaN cloud top temp as we do not have GOES16 cloud top temp for then  


cat merge.cdf | uniput ../2013_gabrielle1.nc
