

avapsgetstormspeed.sh /home/pi/Desktop/STORM_REPORTS/REPORT_10_NICOLE.txt 2010 09 28 16 15
#Storm speed (vx, vy): 1.843277 3.086417 

avapslonlatStorm.sh 1.8 3.1 58.5

avaps3dvarONR_withoutRADAR.sh 2010 09 28 mask -87 0.25 34 16 0.25 18 0 0.2 81 1.8 3.1 58.5 4 14 2
# use NaN cloud top temp as we do not have GOES16 cloud top temp for then  


cat merge.cdf | uniput ../2010_nicole2.nc
