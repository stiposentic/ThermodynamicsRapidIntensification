

avapsgetstormspeed.sh /home/pi/Desktop/STORM_REPORTS/REPORT_10_KARL.txt 2010 09 14 17 00
#Storm speed (vx, vy): -6.601502 2.657748 

avapslonlatStorm.sh -6.6 2.7 61.2

avaps3dvarONR_withoutRADAR.sh 2010 09 14 mask -86.5 0.25 34 15 0.25 20 0 0.2 81 -6.6 2.7 61.2 4 14 2
# use NaN cloud top temp as we do not have GOES16 cloud top temp for then  


cat merge.cdf | uniput ../2010_karl6.nc
