

avapsgetstormspeed.sh /home/pi/Desktop/STORM_REPORTS/REPORT_23_LEE.txt 2023 09 15 08 30
#Storm speed (vx, vy): 0.771604 7.587441 
avapslonlatStorm.sh 0.8 7.6 31.05


# using storm speed from NHC reports: 
avaps3dvarONR_withoutRADAR.sh 2023 09 15 mask -71 0.25 30 31 0.25 30 0 0.2 81 0.8 7.6 31.05 7 11 0

cat merge.cdf | uniput ../2023_lee10.nc
