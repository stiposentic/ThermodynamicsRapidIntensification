

avapsgetstormspeed.sh /home/pi/Desktop/STORM_REPORTS/REPORT_10_FIONA.txt 2010 08 31 13 00
#Storm speed (vx, vy): -11.659796 1.028806 

avapslonlatStorm.sh -11.7 1.0 46.8

avaps3dvarONR_withoutRADAR.sh 2010 08 31 mask -58.5 0.25 36 11 0.25 36 0 0.2 81 -11.7 1.0 46.8 4 14 2
# use NaN cloud top temp as we do not have GOES16 cloud top temp for then  


cat merge.cdf | uniput ../2010_fiona2.nc
