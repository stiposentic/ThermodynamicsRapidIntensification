

avapsgetstormspeed.sh /home/pi/Desktop/STORM_REPORTS/REPORT_23_LEE.txt 2023 09 14 09 00
# Storm speed (vx, vy): -2.057611 5.658431 

avapslonlatStorm.sh -2.1 5.7 32.4

avaps3dvarONR_withoutRADAR.sh 2023 09 14 mask -71 0.25 28 26 0.25 28 0 0.2 81 -2.1 5.7 32.4 7 11 0

cat merge.cdf | uniput ../2023_lee08.nc
