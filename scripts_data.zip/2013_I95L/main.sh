

#avapsgetstormspeed.sh /home/pi/Desktop/STORM_REPORTS/REPORT_13_HUMBERTO.txt 2013 09 16 23 59
# gabrielle 1 speed: 0 0
# as it was a depression and not noted in the NHC reports
#Storm speed (vx, vy): 0.507258 0.514403 


# ana's speed: -2.4 0.0


avapslonlatStorm.sh -2.4 0.0 86.4


avaps3dvarONR_withoutRADAR.sh 2013 09 19 mask -97.5 0.25 32 18.5 0.25 30 0 0.2 81 -2.4 0.0 86.4 18 29 2
# use NaN cloud top temp as we do not have GOES16 cloud top temp for then  


cat merge.cdf | uniput ../2013_I95L.nc
