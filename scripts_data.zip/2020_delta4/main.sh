avapsgetstormspeed.sh /home/pi/Desktop/STORM_REPORTS/REPORT_20_DELTA.txt 2020 10 08 09 00 
#Storm speed (vx, vy): -5.658431 3.600819 

avapslonlatStorm.sh -5.7 3.6 32.4

avaps3dvarONR_withoutRADAR.sh 2020 10 08 mask -96 0.25 36 21 0.25 32 0 0.2 81 -5.7 3.6 32.4 7 11 1

cat merge.cdf | uniput -r ../2020_delta4.nc
