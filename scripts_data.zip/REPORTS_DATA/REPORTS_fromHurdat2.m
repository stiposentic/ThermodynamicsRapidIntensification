clear all
close all

% Get and write reports from hurdat data and the 2022 storm data

% cycle through all Atlantic storms from 2020 to 2022
fid = fopen('hurdat2-1851-2022-050423.txt','r');
line = fgetl(fid); 
while line>0
    year = str2num(line(5:8));
    yearR = line(7:8);
    name = strtrim(line(10:28));
    numLines = str2num(line(30:36));
    
    if year >= 2008
        fileOut = ['REPORT_' yearR '_' name '.txt'];
        fidR = fopen(fileOut,'w');
        for i = 1:numLines %get all lines with data
            line = fgetl(fid);
            
            monthR = str2num(line(5:6));
            dayR   = str2num(line(7:8));
            hrR    = str2num(line(11:12));
            minR   = str2num(line(13:14));
            stormType = line(20:21);
            if strcmp(stormType,'TD')
                storm = 1;
            elseif strcmp(stormType,'TS')
                storm = 2;
            elseif strcmp(stormType,'HU')
                storm = 3;
            elseif strcmp(stormType,'EX')
                storm = 4;
            elseif strcmp(stormType,'SD')
                storm = 11;
            elseif strcmp(stormType,'SS')
                storm = 12;
            elseif strcmp(stormType,'LO')
                storm = 13;
            elseif strcmp(stormType,'DB')
                storm = 14;
            end
            lonR   = -str2num(line(31:35));
            if strcmp(line(36),'E'); lonR = -lonR; end
            latR   = str2num(line(24:27));
            if strcmp(line(28),'S'); latR = -latR; end
            windKnotsR = str2num(line(39:41));
            windR = windKnotsR * 0.5144444; % knots to m/s
            pressureR = str2num(line(44:47));
            fprintf(fidR,'%i %i %i %i %i %.2f %.2f %.2f %.2f %i\n',...
                year, monthR, dayR, hrR, minR, latR, lonR, ...
                windR, pressureR, storm)
        end
        fclose(fidR)
        line = fgetl(fid); % continue while loop
    else
        for i = 1:numLines %skip all lines for storms we do not look at
            line = fgetl(fid);            
        end
        line = fgetl(fid); % continue while loop
    end
end % outer while loop
fclose(fid)


% %%
% % % read hurdat data for 2022 from individual file
% fid = fopen('hurdat2-2022.txt','r');
% line = fgetl(fid); 
% year = 2022;
% yearR = '22';
% data = [];
% num0 = 1;
% while line>0
%     [num, monthR, dayR, hourR, minuteR, storm, ...
%           lonR, latR, windR, pressureR, NAME] = parseLine(line);
%     if num == num0
%         data = [data; num, monthR, dayR, hourR, minuteR, storm, ...
%                      lonR, latR, windR, pressureR];
%         nameStorm = strtrim(NAME);
%     else
%         %write data
%         fileOut = ['REPORT_' yearR '_' nameStorm '.txt'];
%         fidR = fopen(fileOut,'w');
%         for i = 1:size(data,1)
%             fprintf(fidR,'%i %i %i %i %i %.2f %.2f %.2f %.2f %i\n',...
%                 year, data(i,2), data(i,3), data(i,4), data(i,5), ...
%                 data(i,8), data(i,7), ...
%                 data(i,9), data(i,10), data(i,6));
%         end
%         fclose(fidR);
%         % zero out data storage
%         data = []; 
%         % reset num counter
%         num0 = num;
%     end
%     line = fgetl(fid);
% end
% fclose(fid)
% % print last storm from file as num==num0 is not tested after last line
%         fileOut = ['REPORT_' yearR '_' name '.txt'];
%         fidR = fopen(fileOut,'w');
%         for i = 1:size(data,1)
%             fprintf(fidR,'%i %i %i %i %i %.2f %.2f %.2f %.2f %i\n',...
%                 year, data(i,2), data(i,3), data(i,4), data(i,5), ...
%                 data(i,8), data(i,7), ...
%                 data(i,9), data(i,10), data(i,6));
%         end
%         fclose(fidR);



%functions used in this script
function [num, monthR, dayR, hourR, minuteR, storm, ...
          lonR, latR, windR, pressureR, NAME] = parseLine(line)
    num = str2num(line(5:6));
    monthR = str2num(line(13:14));
    dayR = str2num(line(15:16));
    hourR = str2num(line(17:18));
    minuteR = 0; 
    stormType = line(60:61);
    if strcmp(stormType,'TD')
        storm = 1;
    elseif strcmp(stormType,'TS')
        storm = 2;
    elseif strcmp(stormType,'HU')
        storm = 3;
    elseif strcmp(stormType,'EX')
        storm = 4;
    elseif strcmp(stormType,'SD')
        storm = 11;
    elseif strcmp(stormType,'SS')
        storm = 12;
    elseif strcmp(stormType,'LO')
        storm = 13;
    elseif strcmp(stormType,'DB')
        storm = 14;
    end
    lonR   = -str2num(line(42:45))/10;
    if strcmp(line(46),'E'); lonR = -lonR; end
    latR   = str2num(line(35:38))/10;
    if strcmp(line(39),'S'); latR = -latR; end
    windKnotsR = str2num(line(49:51));
    windR = windKnotsR * 0.5144444; % knots to m/s
    pressureR = str2num(line(54:57));
    NAME = line(149:159);
end

