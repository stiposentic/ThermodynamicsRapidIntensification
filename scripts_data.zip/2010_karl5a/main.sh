

avapsgetstormspeed.sh /home/pi/Desktop/STORM_REPORTS/REPORT_10_KARL.txt 2010 09 13 21 00
#Storm speed (vx, vy): -3.343618 0.771604

avapslonlatStorm.sh -3.3 0.8 75.6

avaps3dvarONR_withoutRADAR.sh 2010 09 13 mask -81.5 0.25 28 14.5 0.25 22 0 0.2 81 -3.3 0.8 75.6 4 14 2
# use NaN cloud top temp as we do not have GOES16 cloud top temp for then  


cat merge.cdf | uniput ../2010_karl5a.nc
