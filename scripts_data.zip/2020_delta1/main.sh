
avapsgetstormspeed.sh /home/pi/Desktop/STORM_REPORTS/REPORT_20_DELTA.txt 2020 10 06 23 00
#Storm speed (vx, vy): -6.687236 4.029488
avapslonlatStorm.sh -6.7 4.0 82.8

avaps3dvarONR_withoutRADAR.sh 2020 10 06 mask -88.5 0.25 30 16 0.25 36 0 0.2 81 -6.7 4.0 82.8 21 24 0

cat merge.cdf | uniput -r ../2020_delta1.nc
