
avapsgetstormspeed.sh /home/pi/Desktop/STORM_REPORTS/REPORT_21_GRACE.txt 2021 08 15 18 30
# Storm speed (vx, vy): -6.730103 0.514403 

avapslonlatStorm.sh -6.7 0.5 66.6

avaps3dvarONR_withoutRADAR.sh 2021 08 15 mask -69.5 0.25 26 14 0.25 28 0 0.2 81 -6.7 0.5 66.6 15 21 1

cat merge.cdf | uniput -r ../2021_grace2.nc
