

avapsgetstormspeed.sh /home/pi/Desktop/STORM_REPORTS/REPORT_23_LEE.txt 2023 09 13 20 45
#Storm speed (vx, vy): -1.993311 5.079727 
avapslonlatStorm.sh -2.0 5.1 74.7


# using storm speed from NHC reports: 
avaps3dvarONR_withoutRADAR.sh 2023 09 13 mask -72.5 0.25 32 24 0.25 30 0 0.2 81 -2.0 5.1 74.7 18 23 0

cat merge.cdf | uniput ../2023_lee07.nc
