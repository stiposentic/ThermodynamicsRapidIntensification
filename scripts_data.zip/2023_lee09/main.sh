

avapsgetstormspeed.sh /home/pi/Desktop/STORM_REPORTS/REPORT_23_LEE.txt 2023 09 14 20 45
#Storm speed (vx, vy): -0.042867 6.687236 
avapslonlatStorm.sh 0.0 6.7 74.7


# using storm speed from NHC reports: 
avaps3dvarONR_withoutRADAR.sh 2023 09 14 mask -72 0.25 40 28.5 0.25 28 0 0.2 81 0.0 6.7 74.7 19 23 0

cat merge.cdf | uniput ../2023_lee09.nc
