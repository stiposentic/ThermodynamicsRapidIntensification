
avapsgetstormspeed.sh /home/pi/Desktop/STORM_REPORTS/REPORT_20_MARCO.txt 2020 08 23 08 30
#Storm speed (vx, vy): -2.872082 5.358362 
avapslonlatStorm.sh -2.9 5.4 30.6

avaps3dvarONR_withoutRADAR.sh 2020 08 23 mask -90.5 0.25 28 17.5 0.25 42 0 0.2 81 -2.9 5.4 30.6 6 11 1

cat merge.cdf | uniput -r ../2020_marco2.nc
