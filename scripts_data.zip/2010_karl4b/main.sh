

avapsgetstormspeed.sh /home/pi/Desktop/STORM_REPORTS/REPORT_10_KARL.txt 2010 09 12 21 30
#Storm speed (vx, vy): NaN NaN

# taken from Saskas work
avapslonlatStorm.sh -6.7 1.5 77.4

avaps3dvarONR_withoutRADAR.sh 2010 09 12 mask -76.5 0.25 24 13.5 0.25 24 0 0.2 81 -6.7 1.5 77.4 4 14 2
# use NaN cloud top temp as we do not have GOES16 cloud top temp for then  


cat merge.cdf | uniput ../2010_karl4b.nc
