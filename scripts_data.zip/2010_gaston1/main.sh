

avapsgetstormspeed.sh /home/pi/Desktop/STORM_REPORTS/REPORT_10_GASTON.txt 2010 09 02 17 15
#Storm speed (vx, vy): -3.665120 0.964505 

avapslonlatStorm.sh -3.7 1.0 62.1

avaps3dvarONR_withoutRADAR.sh 2010 09 02 mask -47.5 0.25 40 11.5 0.25 22 0 0.2 81 -3.7 1.0 62.1 4 14 2
# use NaN cloud top temp as we do not have GOES16 cloud top temp for then  


cat merge.cdf | uniput ../2010_gaston1.nc
