

avapsgetstormspeed.sh /home/pi/Desktop/STORM_REPORTS/REPORT_13_GABRIELLE.txt 2013 09 04 22 00
# Gabrielle 2 Storm speed (vx, vy): -0.171468 0.214334
##Storm speed (vx, vy): -1.200273 1.500341 21:30 ref time 
#Storm speed (vx, vy): -1.371741 1.714676  22 ref time

avapslonlatStorm.sh -1.4 1.7 79.2

# using storm speed from radar data
avaps3dvarONR_withoutRADAR.sh 2013 09 04 mask -68.5 0.25 22 15.5 0.25 32 0 0.2 81 -1.4 1.7 79.2 19 25 2
# use NaN cloud top temp as we do not have GOES16 cloud top temp for then  


cat merge.cdf | uniput ../2013_gabrielle2.nc
