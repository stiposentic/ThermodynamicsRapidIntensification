

avapsgetstormspeed.sh /home/pi/Desktop/STORM_REPORTS/REPORT_23_LEE.txt 2023 09 11 09 30
# Storm speed (vx, vy): -2.271946 2.529147 
avapslonlatStorm.sh -2.3 2.5 34.2



# using storm speed from NHC reports: 
avaps3dvarONR_withoutRADAR.sh 2023 09 11 mask -67 0.25 28 20 0.25 26 0 0.2 81 -2.3 2.5 34.2 7 12 0


cat merge.cdf | uniput ../2023_lee02.nc
