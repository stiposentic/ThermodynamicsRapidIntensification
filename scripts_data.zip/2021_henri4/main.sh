avapsgetstormspeed.sh /home/pi/Desktop/STORM_REPORTS/REPORT_21_HENRI.txt 2021 08 21 09 00
#Storm speed (vx, vy): 2.572014 5.144028 

avapslonlatStorm.sh 2.6 5.1 32.4


avaps3dvarONR_withoutRADAR.sh 2021 08 21 mask -76 0.25 38 28 0.25 40 0 0.2 81 2.6 5.1 32.4 6 12 0

cat merge.cdf | uniput -r ../2021_henri4.nc




