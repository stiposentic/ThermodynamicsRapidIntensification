
avapsgetstormspeed.sh /home/pi/Desktop/STORM_REPORTS/REPORT_22_IAN.txt 2022 09 25 09 00
#Storm speed (vx, vy): -5.658431 1.028806

avapslonlatStorm.sh -5.7 1.0 32.4

# using storm speed from radar data
avaps3dvarONR_withoutRADAR.sh 2022 09 25 mask -82.5 0.25 28 11.5 0.25 36 0 0.2 81 -5.7 1.0 32.4 7 11 0

cat merge.cdf |  uniput  ../2022_ian2.nc
