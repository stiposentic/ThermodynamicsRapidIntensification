

avapsgetstormspeed.sh /home/pi/Desktop/STORM_REPORTS/REPORT_23_LEE.txt 2023 09 12 09 30
# Storm spesed (vx, vy): -3.043550 0.600137 
avapslonlatStorm.sh -3.0 0.6 34.2


# using storm speed from NHC reports: 
avaps3dvarONR_withoutRADAR.sh 2023 09 12 mask -69 0.25 36 21 0.25 28 0 0.2 81 -3.0 0.6 34.2 7 12 0


cat merge.cdf | uniput ../2023_lee04.nc
