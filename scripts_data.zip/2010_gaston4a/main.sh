

avapsgetstormspeed.sh /home/pi/Desktop/STORM_REPORTS/REPORT_10_GASTON.txt 2010 09 06 21 30
#Storm speed (vx, vy): -9.044916 -0.085734 

avapslonlatStorm.sh -9.0 -0.1 77.4

avaps3dvarONR_withoutRADAR.sh 2010 09 06 mask -61 0.25 24 15.5 0.25 22 0 0.2 81 -9.0 -0.1 77.4 4 14 2
# use NaN cloud top temp as we do not have GOES16 cloud top temp for then  


cat merge.cdf | uniput ../2010_gaston4a.nc
