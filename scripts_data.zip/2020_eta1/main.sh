
avapsgetstormspeed.sh /home/pi/Desktop/STORM_REPORTS/REPORT_20_ETA.txt 2020 11 07 11 00 
# Storm speed (vx, vy): 9.259250 4.458157 

avapslonlatStorm.sh 9.3 4.5 39.6

avaps3dvarONR_withoutRADAR.sh 2020 11 07 mask -88.5 0.25 38 15.50 0.25 44 0 0.2 81 9.3 4.5 39.6 6 13 1


cat merge.cdf | uniput -r ../2020_eta1.nc

