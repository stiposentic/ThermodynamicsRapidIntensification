

avapsgetstormspeed.sh /home/pi/Desktop/STORM_REPORTS/REPORT_13_GABRIELLE.txt 2013 09 07 22 45
# Gabrielle 3 Storm speed (vx, vy): 0.748020 3.725860
# Storm speed (vx, vy): 0.407236 4.115222 

avapslonlatStorm.sh 0.4 4.1 81.9

# using storm speed from radar data
avaps3dvarONR_withoutRADAR.sh 2013 09 07 mask -74.5 0.25 48 20 0.25 28 0 0.2 81 0.4 4.1 81.9 4 14 2
# use NaN cloud top temp as we do not have GOES16 cloud top temp for then  


cat merge.cdf | uniput ../2013_gabrielle3.nc
