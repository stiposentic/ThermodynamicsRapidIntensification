
avapsgetstormspeed.sh /home/pi/Desktop/STORM_REPORTS/REPORT_22_IAN.txt 2022 08 10 16 30
#Storm speed (vx, vy): -3.815154 4.543891 

avapslonlatStorm.sh 0 0 59.4

# storm relative to dropsondes
avaps3dvarONR_withoutRADAR.sh 2022 08 10 mask -42 0.25 48 9 0.25 34 0 0.2 81 0.0 0.0  59.4 13 18 0

cat merge.cdf  | uniput ../2022_ITOFS_East.nc
