avapsgetstormspeed.sh /home/pi/Desktop/STORM_REPORTS/REPORT_21_HENRI.txt 2021 08 20 09 00
#Storm speed (vx, vy): -4.115222 1.028806 

avapslonlatStorm.sh -4.1 1.2 32.4


avaps3dvarONR_withoutRADAR.sh 2021 08 20 mask -76 0.25 40 26 0.25 40 0 0.2 81 -4.1 1.2 32.4 6 12 0

cat merge.cdf | uniput -r ../2021_henri2.nc




