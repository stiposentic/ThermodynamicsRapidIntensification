
avapsgetstormspeed.sh /home/pi/Desktop/STORM_REPORTS/REPORT_21_GRACE.txt 2021 08 18 22 00
#Storm speed (vx, vy): -8.744847 1.028806 

avapslonlatStorm.sh -8.7 1.0 79.2


avaps3dvarONR_withoutRADAR.sh 2021 08 18 mask -87.5 0.25 26 16.5 0.25 28 0 0.2 81 -8.7 1.0 79.2 17 23 0

cat merge.cdf | uniput -r ../2021_grace3.nc


