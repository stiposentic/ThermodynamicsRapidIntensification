
avapsgetstormspeed.sh /home/pi/Desktop/STORM_REPORTS/REPORT_22_IAN.txt 2022 09 25 20 30
#Storm speed (vx, vy): -3.815154 4.543891 

avapslonlatStorm.sh -3.8 4.5 73.8

# storm relative to dropsondes
avaps3dvarONR_withoutRADAR.sh 2022 09 25 mask -83.5 0.25 24 12.5 0.25 28 0 0.2 81 -2.79 4.84  73.8 19 22 0

cat merge.cdf  | uniput ../2022_ian3.nc
