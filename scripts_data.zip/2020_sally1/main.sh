
#vaps3dvarVmoveRadar.sh 2020 09 13 mask -90 0.25 32 24 0.25 28 0 0.2 81 -3.8 1.8 76.5

avapsgetstormspeed.sh /home/pi/Desktop/STORM_REPORTS/REPORT_20_SALLY.txt 2020 09 13 21 45
# Storm speed from HURDAT2 (vx, vy): -3.665120 1.736109 

# However, u= -3.8, v = 1.8, is the speed used 
# in our Sally paper, so I leave it so, since it
# is very close
avapslonlatStorm.sh -3.8 1.8 76.5

# using storm speed from radar data
avaps3dvarONR_withoutRADAR.sh 2020 09 13 mask -90 0.25 32 24 0.25 28 0 0.2 81 -3.8 1.8 76.5 8 23 0


cat merge.cdf | uniput ../2020_sally1.nc
