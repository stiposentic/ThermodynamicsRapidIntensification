

avapsgetstormspeed.sh /home/pi/Desktop/STORM_REPORTS/REPORT_10_ALEX.txt 2010 06 29 21 30
#Storm speed (vx, vy): -4.329557 1.371741 

avapslonlatStorm.sh -4.3 1.4 77.4

avaps3dvarONR_withoutRADAR.sh 2010 06 29 mask -97.5 0.25 50 18.5 0.25 44 0 0.2 81 -4.3 1.4 77.4 4 14 2
# use NaN cloud top temp as we do not have GOES16 cloud top temp for then  


cat merge.cdf | uniput ../2010_alex2.nc
