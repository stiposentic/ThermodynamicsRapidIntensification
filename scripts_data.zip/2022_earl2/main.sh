avapsgetstormspeed.sh /home/pi/Desktop/STORM_REPORTS/REPORT_22_EARL.txt 2022 08 31 22 30
#Storm speed (vx, vy): -2.443413 1.028806   

avapslonlatStorm.sh -2.4 1.0 81.0


avaps3dvarONR_withoutRADAR.sh 2022 08 31 mask -60.5 0.25 52 13.5 0.25 30 0 0.2 81 -2.4 1.0 81.0 19 26 1

cat merge.cdf | uniput -r ../2022_earl2.nc


