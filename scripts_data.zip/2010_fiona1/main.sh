

avapsgetstormspeed.sh /home/pi/Desktop/STORM_REPORTS/REPORT_10_FIONA.txt 2010 08 30 13 00
#Storm speed (vx, vy): -9.859387 1.714676

avapslonlatStorm.sh -9.9 1.7 46.8

avaps3dvarONR_withoutRADAR.sh 2010 08 30 mask -50.5 0.25 36 11 0.25 28 0 0.2 81 -9.9 1.7 46.8 4 14 2
# use NaN cloud top temp as we do not have GOES16 cloud top temp for then  


cat merge.cdf | uniput ../2010_fiona1.nc
