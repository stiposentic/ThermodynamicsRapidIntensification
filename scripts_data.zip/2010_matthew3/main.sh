

avapsgetstormspeed.sh /home/pi/Desktop/STORM_REPORTS/REPORT_10_MATTHEW.txt 2010 09 22 16 00
#Storm speed (vx, vy): -6.0 0.0 at 14:30utc
# Values take nfrom Saskas work as we do not have BT data forthis time

avapslonlatStorm.sh -6.0 0.0 57.6

avaps3dvarONR_withoutRADAR.sh 2010 09 22 mask -73.75 0.25 33 12 0.25 18 0 0.2 81 -6.0 0.0 57.6 4 14 2
# use NaN cloud top temp as we do not have GOES16 cloud top temp for then  


cat merge.cdf | uniput ../2010_matthew3.nc
