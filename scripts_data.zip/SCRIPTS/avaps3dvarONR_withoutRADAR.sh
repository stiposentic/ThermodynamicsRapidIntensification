#!/bin/bash
#
# avaps3dvar.sh -- Do 3DVAR analysis from dropsonde grid
#                  With Juracic and Raymond (2016) entropy
#                  and moisture budgets
#
if test $# != 19
then
	echo "Usage: avaps3dvar.sh year month day mask lon0 dlon nlon lat0 dlat nlat z0 dz nz svx svy reftime(ks) avapsHourStart avapsHourEnd retrieveCloudTopTempSwitch0or1"
else

    # get command line arguments
    year=$1
    shift
    month=$1
    shift
    day=$1
    shift
    mask=$1
    shift
    lon0=$1
    shift
    dlon=$1
    shift
    nlon=$1
    shift
    lat0=$1
    shift
    dlat=$1
    shift
    nlat=$1
    shift
    z0=$1
    shift
    dz=$1
    shift
    nz=$1
    shift
    svx=$1
    shift
    svy=$1
    shift
    reftime=$1
    shift
    avapsStartHour=$1
    shift
    avapsEndHour=$1
    shift
    retrieveCloudTop=$1


    # generate the jday for the date of the observations
    jday0=`jday.sh $year $month $day`
    echo $jday0

    # generate cdf maskfile from text mask file, which must be created
    # beforehand (do man gomask)
    gomask $mask lon lat $lon0 $lat0 $dlon $dlat $nlon $nlat


    # get the Reynolds SST matching the specified domain
echo Retrieving SST file...
    rm oisst-avhrr-*.nc
    rm avhrsst_*.cdf
    avapsgetsst.sh $year $month $day
    sstfile=avhrsst_${year}${month}${day}.cdf
    lon1=$lon0
    lon2=`echo "scale = 2; $lon1 + ($nlon - 1)*$dlon" | bc`
    lat1=$lat0
    lat2=`echo "scale = 2; $lat1 + ($nlat - 1)*$dlat" | bc`
    echo lon $lon1 $lon2 lat $lat1 $lat2
    if [ "$dlon" = "0.25" ]; then
	    sparse=1
    elif [ "$dlon" = "0.5" ]; then
	    sparse=2
    fi
    cat $sstfile |\
    cdfthin lon $sparse lat $sparse |\
    cdfwindow lon $lon1 $lon2 lat $lat1 $lat2 | \
	cdfmath 'jday jdaysst =' | \
	cdfextr -s lon lat | \
	cdfextr jdaysst sst > sst.cdf

    cdfcatf Z*.cdf | cdfcat ztime 0 986400 999 |\
    cdfextr -s ztime |\
    cdfextr lon.m lat.m > lonlat.cdf

    # Retrieved from GOES
    HOURS=`seq $avapsStartHour $avapsEndHour`
    if [ "$retrieveCloudTop" == "1" ]; then
    echo Retrieving GOES cloud top temperature data
      for hour1 in $HOURS
      do
	hour0=`printf "%02d" $hour1`
	if [ "$hour1" -gt "23" ]; then
		hourIn=`echo $hour1 - 24 | bc `
		hourIn=`printf "%02d" $hourIn`
		jdayIn=`echo $jday0 + 1 | bc`
	else 
		hourIn=$hour0
		jdayIn=$jday0
	fi
        echo $year $jdayIn $hourIn
        # download the GOES 16 cloout top temperature files
	aws s3 ls --no-sign-request s3://noaa-goes16/ABI-L2-ACHTF/$year/$jdayIn/$hourIn/ > tmp
        file=`cat tmp | sed -n "/OR_ABI-L2-ACHTF-M6_G16/p" | head -1 | cut -d" " -f6`
        filep="s3://noaa-goes16/ABI-L2-ACHTF/$year/$jdayIn/$hourIn/$file"
        aws s3 cp --no-sign-request $filep .
	convertFile=`ls OR_ABI-L2-ACHTF-M6_G16_s$year$jdayIn$hourIn*.nc`
	goes16_cdfCloudTop.sh $convertFile
      done
      cdfcatf goes_16_channel_ACHTF_*.cdf |\
      cdfcat t 0 99999999999 999 |\
      cdfrdim t 0 99999999999 |\
      cdfwindow lon $lon1 $lon2 lat $lat1 $lat2 | \
        cdfthin lon $sparse lat $sparse |\
        cdfmath '$jday0 jdaycldtoptemp =' | \
        cdfextr -s lon lat | \
	cdfmath "temp cldtoptemp =" |\
        cdfextr jdaycldtoptemp cldtoptemp > cldtoptemp.cdf
    elif [ "$retrieveCloudTop" == "2" ]; then
        cat ~/bin/goes_16_channel_ACHTF_2020_257_08_00.cdf|\
		cdfthin lon $sparse lat $sparse |\
	cdfwindow lon $lon1 $lon2 lat $lat1 $lat2 | \
        cdfmath '$jday0 jdaycldtoptemp =' | \
        cdfextr -s lon lat | \
        cdfmath "temp 0 * 1e30 + cldtoptemp =" |\
        cdfextr jdaycldtoptemp cldtoptemp > cldtoptemp.cdf

    elif [ "$retrieveCloudTop" == "3" ]; then
	    cat sst.cdf |\
		    cdfmath "1 jdaycldtoptemp =" |\
		    cdfmath "sst 0 * 900 - cldtoptemp =" |\
		    cdfvlim cldtoptemp -50 50 |\
		    cdfextr jdaycldtoptemp cldtoptemp > cldtoptemp.cdf
	     
    fi

    echo here
    # dry air gas constant
    R=273

    # this value seems to remove single sonde artifacts without damping things
    # too much
    hsmooth=1.00

    # we need a bit of vertical smoothing
    vsmooth=0.05
    
    # compute the input to ngradcart from dropsondes, NO RADAR
    cdfcatf Z*.cdf | \
    ngauxcart -l -s $svx:$svy:$reftime -- $jday0 $lon0 $dlon $nlon $lat0 $dlat $nlat $z0 $dz $nz > temp1
    
    # run the 3dvar toolchain to get gridded, consistent winds
    ngradcart -l -a temp1 -s $svx:$svy:$reftime -x -- $lon0 $dlon $nlon $lat0 $dlat $nlat $z0 $dz $nz | \
	ng3dvar --phs=$hsmooth --pvs=$vsmooth | \
	cdfextr -p lon0 dlon lat0 dlat z0 dz | \
	cdfextr -s lon lat z > temp2

echo Calculating vorticities

    # compute the relative and absolute vorticity, the divergence, and
    # the vertical mass flux
    lonlatdiv.sh lon lat u v div < temp2 | \
	lonlatzcurl.sh u v relvort | \
	lonlatvort.sh u v w xvort yvort absvort | \
	cdfmath "rho w * mflux =" | \
	cdfextr rho u v w relvort absvort div mflux > temp5

    # compute mfluxlo and mfluxhi (3-5 km and 7-9 km)
    cdfrdim z 3 5 < temp5 | \
	cdfmath 'mflux mfluxlo =' | \
	cdfextr mfluxlo | \
	cdfextr -s lon lat > mfluxlo.cdf
    cdfrdim z 7 9 < temp5 | \
	cdfmath 'mflux mfluxhi =' | \
	cdfextr mfluxhi | \
	cdfextr -s lon lat > mfluxhi.cdf

    # merge with winds and compute mfluxdif
    cdfmerge temp5 '' mfluxlo.cdf '' mfluxhi.cdf '' | \
	cdfmath 'mfluxhi mfluxlo - mfluxdif =' | \
	cdfextr -s lon lat z > winds.cdf

echo Calculating 3Dvar scalars

    # do 3dvar on the scalar variables -- need to change some variable
    # names and units -- also put in jday0
    # dew point temp gotten from:
    # https://www.vcalc.com/wiki/rklarsen/Calculating+Dew+Point+Temperature+from+Relative+Humidity
    cdfcatf Z*.cdf  | \
	cdfmath 'lon.m lon =' | cdfmath 'lat.m lat =' | \
	cdfmath 'ztime 1000 / monotime =' | \
	cdfmath "rh 100 / log   17.625 temp * 243.04 temp + /   +    243.04 * num =" |\
	cdfmath "17.625 rh 100 / log  - 17.625 temp * 243.04 temp + / -  den =" |\
	cdfmath "num den / dewpt =" |\
	cdfextr lon lat monotime pres temp dewpt | \
	ngsonde --phs $hsmooth --pvs $vsmooth -s $svx:$svy:$reftime \
           	--idx z --lon $lon0:$dlon:$nlon \
		 --lat $lat0:$dlat:$nlat --alt $z0:$dz:$nz \
		 pres temp dewpt | \
	cdfmr pres temp dewpt mr | \
	cdfmr pres temp temp satmr | \
	cdfmath "pres 100 * $R / temp 273.15 + / rhotherm =" | \
	cdfmath "$jday0 jday0 =" | \
  cdfentropy -q pres temp mr ent dummy | \
  cdfentropy -d pres temp temp satent dummy > thermo.cdf

echo Calculating saturation fraction

    # compute saturation fraction
    cdfmath "mr rhotherm * rhomr =" < thermo.cdf | \
	cdfmath "satmr rhotherm * rhosatmr =" | \
	cdfdefint z | \
	cdfmath "rhomr rhosatmr / sfrac =" | \
	cdfextr -s lon lat | \
	cdfextr sfrac > sfrac.cdf

echo Calculating instability index 
    # compute instability index
    cdfrdim z 1 3 < thermo.cdf | \
	cdfextr satent > temp3
    cdfrdim z 5 7 < thermo.cdf | \
	cdfextr satent > temp4
    cdfmerge temp3 '' temp4 '' | \
	cdfmath 'satent satent. - ii =' | \
	cdfextr -s lon lat | \
	cdfextr ii > ii.cdf
	
echo Calculating DCIN

    # dcin
     cat thermo.cdf | cdfextr ent | cdfrdim z 0 1 | cdfmath 'ent entlo =' | cdfextr -rs z | cdfextr entlo > tmpdcinlo.cdf
     cat thermo.cdf | cdfextr satent | cdfrdim z 1.5 2 | cdfmath 'satent enthi =' | cdfextr -rs z | cdfextr enthi > tmpdcinhi.cdf
     cdfmerge tmpdcinlo.cdf '' tmpdcinhi.cdf '' | cdfmath 'enthi entlo - dcin =' | cdfextr dcin > tmpdcin.cdf


echo Calculating surface fluxes
  cdfmerge thermo.cdf '' winds.cdf ''|\
  cdfrdim z 0 |\
  cdfmath "u u10 =" |\
  cdfmath "v v10 =" |\
  cdfmath "mr satmr / 100 * RH =" |\
  cdfextr temp u10 v10 RH > thermo10m.cdf

  cat thermo.cdf |\
  cdfrdim z 0 |\
  cdfmath "pres pres0 =" |\
  cdfextr pres0 > thermo0m.cdf

  cdfmerge thermo10m.cdf '' thermo0m.cdf '' sst.cdf '' mask.cdf '' |\
  cdfextr sst temp u10 v10 RH mask pres0 |\
  cdfvlim sst 0 500 |\
  cdfmath "pres0 vpres =" |\
  # temp and sst already in Centigrade
  #cdfmath "temp 273.15 - temp =" |\
  #cdfmath "sst 273.15 - sst =" |\
  cdfentropy -d vpres temp temp satent satmr | \
  cdfentropy -d vpres sst sst satentsst satmrsst | \
  cdfmath "RH 100 / satmr * 1000 / mr =" |\
  cdfmath "mr 1000 * mixrat =" |\
  cdfentropy -q vpres temp mixrat ent satmr | \
  cdfmath "mr 1 mr + / q =" |\
  cdfmath "satmrsst 1000 / 1 satmrsst 1000 / + / qsat =" |\
  cdfmath "vpres 100 * temp 273.15 + / 287 / rho =" |\
  cdfmath "u10 u10 * v10 v10 * + 0.5 pow UU10 =" |\
  # fluxes from Juracic and Raymond (2016)
  cdfmath "0.00118 UU10 * rho * satentsst ent - *  Fss =" |\
  cdfmath "0.00118 UU10 * rho * satmrsst 1000 / mr - *  Frs =" |\
  # fluxes in W/m2
  cdfmath "0.0018 UU10 * rho * 1004 * sst temp - *  hflux =" |\
  cdfmath "0.0009 2264705 * UU10 * rho * qsat q - * rflux ="  |\
  cdfmath "hflux rflux + entflux =" |\
  cdfextr -rs pres |\
  cdfextr -s lon lat |\
  cdfextr hflux rflux entflux Fss Frs > entflux.cdf

  a=111111

echo Calculating GMS components

  cdfmerge thermo.cdf '' winds.cdf '' |\
  cdfmath "1005 temp 273.15 + 300 / log * 287 pres 1000 / log *  + entd =" |\
  cdfmath "u lat cos * cu =" | \
  cdfderiv dentdlon ent lon |\
  cdfderiv dentdlat ent lat | \
  cdfderiv dentdz ent z |\
  cdfderiv dentddz entd z |\
  cdfmath "u dentdlon * v dentdlat *  +  $a / numH =" |\
  cdfmath "w dentdz * numV =" |\
  cdfmath "w dentddz * denV =" |\
  cdfdefint z |\
  cdfextr -rs z z. lon. lat. |\
  cdfextr numH numV denV > gms.cdf

echo Merge everything
    # merge everything and apply mask
    cdfmerge winds.cdf '' thermo.cdf '' sfrac.cdf '' ii.cdf '' tmpdcin.cdf '' \
	     ${mask}.cdf '' gms.cdf '' lonlat.cdf '' sst.cdf '' entflux.cdf '' \
	     cldtoptemp.cdf '' | \
	cdfextr -p lon0 dlon lat0 dlat z0 dz | \
	cdfextr -s lon lat z ztime | \
	cdfextr jday0 mask rho u v w relvort absvort div mflux pres \
		temp mr satmr ent satent sfrac ii dcin mfluxlo cldtoptemp \
    mfluxhi mfluxdif numH numV denV lon.m lat.m  sst hflux rflux entflux Fss Frs | \
	cdfmath "rho mask * rho =" | \
	cdfmath "u mask * u =" | \
	cdfmath "v mask * v =" | \
	cdfmath "w mask * w =" | \
	cdfmath "relvort mask * relvort =" | \
	cdfmath "absvort mask * absvort =" | \
	cdfmath "div mask * div =" | \
	cdfmath "mflux mask * mflux =" | \
	cdfmath "pres mask * pres =" | \
	cdfmath "temp mask * temp =" | \
	cdfmath "mr mask * mr =" | \
	cdfmath "satmr mask * satmr =" | \
	cdfmath "ent mask * ent =" | \
	cdfmath "satent mask * satent =" | \
	cdfmath "mfluxlo mask * mfluxlo =" | \
	cdfmath "mfluxhi mask * mfluxhi =" | \
	cdfmath "mfluxdif mask * mfluxdif =" | \
	cdfmath "sfrac mask * sfrac =" | \
	cdfmath "ii mask * ii =" |\
	cdfmath "cldtoptemp mask * cldtoptemp =" |\
  cdfmath "hflux mask * hflux =" |\
  cdfmath "rflux mask * rflux =" |\
  cdfmath "entflux mask * entflux =" |\
  cdfmath "Fss mask * Fss =" |\
  cdfmath "Frs mask * Frs =" |\
  cdfmath "dcin mask * dcin =" |\
  cdfmath "numH mask * numH =" |\
  cdfmath "numV mask * numV =" |\
  cdfmath "denV mask * denV =" |\
  cdfmath "dcin 0 > dcin 0 ? dcinn =" | \
  cdfmath "ii 5 > ii 5 ? iindex =" | \
  cdfmath "-28 0.121 entflux * + -2.67 iindex * + 83.3 sfrac * + 4 dcinn * - precipDave =" | \
  cdfmath "precipDave 0 > precipDave 0 ? precipDave =" |\
  cdfmath "precipDave mask * precipDave =" |\
  cdfextr -r dcinn iindex > merge.cdf

    # clean up
    rm temp1 temp2 temp3 temp4 temp5
fi
