

#avapsgetstormspeed.sh /home/pi/Desktop/STORM_REPORTS/REPORT_10_NICOLE.txt 2010 08 17 12 00
#Storm speed (vx, vy): -7.0 0.0 at 14:30 utc (from Saska) 

avapslonlatStorm.sh -7.0 0.0 52.2

avaps3dvarONR_withoutRADAR.sh 2010 08 18 mask -80.5 0.25 35 14.5 0.25 16 0 0.2 81 -7.0 0.0 52.2 4 14 2
# use NaN cloud top temp as we do not have GOES16 cloud top temp for then  


cat merge.cdf | uniput ../2010_PGI027-2.nc
