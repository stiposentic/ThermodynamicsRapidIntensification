avapsgetstormspeed.sh /home/pi/Desktop/STORM_REPORTS/REPORT_22_NICOLE.txt 2022 11 08 20 00
#Storm speed (vx, vy): -5.829898 -1.028806 

avapslonlatStorm.sh -5.8 -1.0 72.0

avaps3dvarONR_withoutRADAR.sh 2022 11 08 mask -78 0.25 28 24 0.25 28 0 0.2 81 -5.8 -1.0 72.0 18 22 1

cat merge.cdf | uniput -r ../2022_nicole2.nc


