avapsgetstormspeed.sh /home/pi/Desktop/STORM_REPORTS/REPORT_21_IDA.txt 2021 08 28 09 00
#Storm speed (vx, vy): -5.658431 4.629625 

avapslonlatStorm.sh -5.7 4.6 32.4


avaps3dvarONR_withoutRADAR.sh 2021 08 28 mask -91 0.25 36 19.5 0.25 34 0 0.2 81 -5.7 4.6 32.4 6 12 0

cat merge.cdf | uniput -r ../2021_ida3.nc




