[dx_dlon, dx_dlat] = ccdfgradlonlat(x,lon,lat);

