

avapsgetstormspeed.sh /home/pi/Desktop/STORM_REPORTS/REPORT_10_ALEX.txt 2010 06 28 21 30
#Storm speed (vx, vy): -0.214334 1.843277 

avapslonlatStorm.sh -0.2 1.8 77.4

avaps3dvarONR_withoutRADAR.sh 2010 06 28 mask -98.25 0.25 58 18 0.25 43 0 0.2 81 -0.2 1.8 77.4 4 14 2
# use NaN cloud top temp as we do not have GOES16 cloud top temp for then  


cat merge.cdf | uniput ../2010_alex1.nc
