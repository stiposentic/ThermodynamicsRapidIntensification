avapsgetstormspeed.sh /home/pi/Desktop/STORM_REPORTS/REPORT_20_LAURA.txt 2020 08 25 22 00 
#Storm speed (vx, vy): -7.030171 3.943755 

avapslonlatStorm.sh -7.0 3.9 79.2

avaps3dvarONR_withoutRADAR.sh 2020 08 25 mask -93 0.25 32 20 0.25 28 0 0.2 81 -7.0 3.9 79.2 18 24 0


cat merge.cdf | uniput -r ../2020_laura6.nc


