#!/bin/bash
#####################################################
#####################################################
## Takes dropsonde files from the OTREC project    ##
## and convertes them to candis formatting         ##
## without any calculations.                       ##
## All output files will have the following naming ##
## convention: YYYYMMDD_HHMMSS_raw.cdf             ##
## Script written by Charles Jensen and modified   ##
## by Dave Raymond                                 ##
#####################################################
#####################################################

if test $# != 1
then
	echo "Usage: $0 eol_dropsonde_file"
else
	# Input file
	infile=$1

	#Header length
	header=22

	# Stuff to collect information from the name of the file
	year=`echo $infile | cut -c 2-5`
	mon=`echo $infile | cut -c 6-7`
	day=`echo $infile | cut -c 8-9`
	hour=`echo $infile | cut -c 11-12`
	min=`echo $infile | cut -c 13-14`
	sec=`echo $infile | cut -c 15-16`

	# Produce the name of the output file
	outfile=Z${year}${month}${day}_${hour}${min}${sec}.cdf

	# create the output file -- convert z to km
	tail -n +$header < $infile | \
		sed -e "s/-999.000/1e30/g" | \
		sed -e "s/-999.00/1e30/g" | \
		sed -e "s/-999.0/1e30/g" | \
		sed -e "s/-999/1e30/g" |\
		sed 'n;d' |\
	        cdftable n time pres temp rh z \
		dir wspd u_wind v_wind ns wz zw fp ft fh fw lat lon  | \
		cdfmath 'z 1000 / z =' |\
		cdfcat index 0 5000 5001  | \
		cdffill index |\
		cdfinvindex index z | \
		cdfwindow z 16 0 | \
		cdfinterp z 16 -0.02 801 | \
		cdfmean z .m lon lat | \
		cdfmath "$year year =" | \
		cdfmath "$mon mon =" | \
		cdfmath "$day day =" | \
		cdfjday year mon day jday $year 1 0 | \
		cdfmath "$hour 3600 * $min 60 * + $sec + ztime =" | \
		cdfmath "jday ztime 86400 / + jday =" | \
		cdfextr -p z0 dz | \
		cdfextr ztime jday lon lat lon.m lat.m pres temp \
			rh u_wind v_wind > $outfile
fi
