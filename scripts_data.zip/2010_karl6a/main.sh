

avapsgetstormspeed.sh /home/pi/Desktop/STORM_REPORTS/REPORT_10_KARL.txt 2010 09 14 21 30
#Storm speed (vx, vy): -6.987304 1.671809 

avapslonlatStorm.sh -7.0 1.7 77.4

avaps3dvarONR_withoutRADAR.sh 2010 09 14 mask -87.75 0.25 29 15.5 0.25 28 0 0.2 81 -7.0 1.7 77.4 4 14 2
# use NaN cloud top temp as we do not have GOES16 cloud top temp for then  


cat merge.cdf | uniput ../2010_karl6a.nc
