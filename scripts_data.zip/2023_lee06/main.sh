

avapsgetstormspeed.sh /home/pi/Desktop/STORM_REPORTS/REPORT_23_LEE.txt 2023 09 13 09 00
# Storm speed (vx, vy): -2.057611 2.057611 
avapslonlatStorm.sh -2.1 2.1 32.4


# using storm speed from NHC reports: 
avaps3dvarONR_withoutRADAR.sh 2023 09 13 mask -71.5 0.25 30 22.5 0.25 32 0 0.2 81 -2.1 2.1 32.4 7 11 0

cat merge.cdf  | uniput ../2023_lee06.nc
