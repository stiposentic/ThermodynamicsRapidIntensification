
avapsgetstormspeed.sh /home/pi/Desktop/STORM_REPORTS/REPORT_20_SALLY.txt 2020 09 14 09 30
# Storm speed from HURDAT2 (vx, vy): -2.271946 1.243140 

# However, u= -2.3, v = 1.2, is the speed used
# in our Sally paper, so I leave it so, since it
# is the same
avapslonlatStorm.sh -2.3 1.2 34.2

avaps3dvarONR_withoutRADAR.sh 2020 09 14 mask -91.5 0.25 30 24.5 0.25 24 0 0.2 81 -2.3 1.2 34.2 6 13 0

cat merge.cdf | uniput ../2020_sally2.nc
