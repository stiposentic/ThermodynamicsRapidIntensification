

avapsgetstormspeed.sh /home/pi/Desktop/STORM_REPORTS/REPORT_14_EDOUARD.txt 2014 09 14 19 00
#Storm speed (vx, vy): -6.172833 3.600819 

avapslonlatStorm.sh -6.2 3.6 68.4

avaps3dvarONR_withoutRADAR.sh 2014 09 14 mask -56 0.25 26 21.5 0.25 52 0 0.2 81 -6.2 3.6 68.4 4 14 2
# use NaN cloud top temp as we do not have GOES16 cloud top temp for then  


cat merge.cdf | uniput ../2014_edouard2.nc
