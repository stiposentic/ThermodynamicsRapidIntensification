

avapsgetstormspeed.sh /home/pi/Desktop/STORM_REPORTS/REPORT_10_MATTHEW.txt 2010 09 21 14 30
#Storm speed (vx, vy): -6.0 0.0 at 14:30utc
# Values take nfrom Saskas work as we do not have BT data forthis time

avapslonlatStorm.sh -6.0 0.0 51.48

avaps3dvarONR_withoutRADAR.sh 2010 09 21 mask -64.5 0.25 34 10 0.25 22 0 0.2 81 -6.0 0.0 51.48 4 14 2
# use NaN cloud top temp as we do not have GOES16 cloud top temp for then  


cat merge.cdf | uniput ../2010_matthew2.nc
