

avapsgetstormspeed.sh /home/pi/Desktop/STORM_REPORTS/REPORT_10_GASTON.txt 2010 09 07 21 30
#Storm speed (vx, vy): -9.173516 0.600137 

avapslonlatStorm.sh -9.2 0.6 77.4

avaps3dvarONR_withoutRADAR.sh 2010 09 07 mask -68.5 0.25 26 15 0.25 20 0 0.2 81 -9.2 0.6 77.4 4 14 2
# use NaN cloud top temp as we do not have GOES16 cloud top temp for then  


cat merge.cdf | uniput ../2010_gaston5a.nc
