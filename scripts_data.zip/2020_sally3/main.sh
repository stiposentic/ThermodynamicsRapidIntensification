

avapsgetstormspeed.sh /home/pi/Desktop/STORM_REPORTS/REPORT_20_SALLY.txt 2020 09 14 19 30
# Storm speed from HURDAT2 (vx, vy): -2.057611 0.900205 

# However, u= -5.0, v = 6.0, is the speed used
# in our Sally paper. Here I change it to beconsistent 
# with HURDAT2 data
avapslonlatStorm.sh -2.1 0.9 70.2

avaps3dvarONR_withoutRADAR.sh 2020 09 14 mask -90.75 0.25 28 25.25 0.25 19 0 0.2 81 -2.1 0.9 70.2 18 21 0

cat merge.cdf | uniput ../2020_sally3.nc


