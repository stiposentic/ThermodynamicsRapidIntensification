

avapsgetstormspeed.sh /home/pi/Desktop/STORM_REPORTS/REPORT_10_NICOLE.txt 2010 09 27 16 00
#Storm speed (vx, vy): 0.0 0.0 at 16utc (from Saska's work)
# Values taken from Saska's work as they are not in BT data

avapslonlatStorm.sh 0.0 0.0 57.6

avaps3dvarONR_withoutRADAR.sh 2010 09 27 mask -87 0.25 48 16 0.25 18 0 0.2 81 0.0 0.0 57.6 4 14 2
# use NaN cloud top temp as we do not have GOES16 cloud top temp for then  


cat merge.cdf | uniput ../2010_nicole1.nc
