avapsgetstormspeed.sh /home/pi/Desktop/STORM_REPORTS/REPORT_21_IDA.txt 2021 08 27 23 30
#Storm speed (vx, vy): -5.197971 5.907314 

avapslonlatStorm.sh -5.2 5.9 84.6


avaps3dvarONR_withoutRADAR.sh 2021 08 27 mask -89 0.25 36 19.5 0.25 32 0 0.2 81 -5.2 5.9 84.6 20 25 0

cat merge.cdf | uniput -r ../2021_ida2.nc




