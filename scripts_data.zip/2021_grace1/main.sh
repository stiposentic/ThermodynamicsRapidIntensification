
avapsgetstormspeed.sh /home/pi/Desktop/STORM_REPORTS/REPORT_21_GRACE.txt 2021 08 14 19 00
#Storm speed (vx, vy): -11.745530 0.685870 

avapslonlatStorm.sh -11.7 0.7 68.4

avaps3dvarONR_withoutRADAR.sh 2021 08 14 mask -63.5 0.25 20 12.5 0.25 34 0 0.2 81 -11.7 0.7 68.4 17 21 0

cat merge.cdf | uniput -r ../2021_grace1.nc
